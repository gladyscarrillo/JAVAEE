package app.daointerface;

import app.entity.Cliente;

public interface IDaoCliente {
	public void insert(Cliente cliente) throws Exception;
	public Cliente getById(String id) throws Exception;
	public void update(Cliente cliente) throws Exception;
	public Iterable<Cliente> findAll() throws Exception;
	
}
