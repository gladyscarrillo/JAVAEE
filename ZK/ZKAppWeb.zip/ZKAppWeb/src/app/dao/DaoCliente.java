package app.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import app.daointerface.IDaoCliente;
import app.entity.Cliente;


public class DaoCliente implements IDaoCliente {
	private EntityManagerFactory emf = null;
	private EntityManager em;

	
	public DaoCliente() {
		 emf = Persistence.createEntityManagerFactory(JPADao.PERSISTANCE_UNIT);
		 em = emf.createEntityManager();
	}

	@Override
	public void insert(Cliente cliente) {
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(cliente);
            tx.commit(); 

        }
        catch (RuntimeException e) {
            tx.rollback();
            throw e;
        }finally {
			if (em!=null) {
				em.close();
				em=null;
			}
			if (emf!=null) {
				emf.close();
				emf=null;
			}
		}
		
		
	}

	@Override
	public Cliente getById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Iterable<Cliente> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
