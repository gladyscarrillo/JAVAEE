package app.dao;

public class JPADao {
	public static final String PERSISTANCE_UNIT = "ZKAppWeb";
}
