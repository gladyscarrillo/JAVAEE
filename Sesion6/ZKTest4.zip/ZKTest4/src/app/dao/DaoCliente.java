package app.dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import app.daointerface.IDaoCliente;

import app.modelo.Cliente;



public class DaoCliente implements IDaoCliente {
	private String rutaArchivo  = "archivos/clientes.csv";
	
	public ArrayList<Cliente> listaClientes ;

	
	public DaoCliente() {
		listaClientes = new ArrayList<Cliente>();
		listaClientes.add(new Cliente("09194342","Gladys","AV23","gelicar@gmail.com"));
	}

	@Override
	public void insert(Cliente cliente) {
        
		
	}

	@Override
	public Cliente getById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Iterable<Cliente> findAll() throws Exception {

		
		String path =  this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		String[] directorio = path.split("classes");
		String rutaCompleta = directorio[0] + rutaArchivo;
		System.out.println("ruta archivo "+rutaCompleta);
		// leer el archivo
		  File archivo = null;
	      FileReader fr = null;
	      BufferedReader br = null;
	      ArrayList<Cliente> clientes = new ArrayList<Cliente>();
	      try {
	         // Apertura del fichero y creacion de BufferedReader para poder
	         // hacer una lectura comoda (disponer del metodo readLine()).
	    	//  FileSystemResource resource = new FileSystemResource("/WEB-INF/content/somecontent.txt");
	         archivo = new File (rutaCompleta);
	         fr = new FileReader (archivo);
	         br = new BufferedReader(fr);

	         // Lectura del fichero
	         String linea;
	         while((linea=br.readLine())!=null) {
	        	 String datos[] = linea.split(",");
	        	 Cliente c = new Cliente(datos[0],datos[1],datos[2],datos[3]);
	        	 System.out.println(c);
	        	 clientes.add(c);
	        	
	         }
	           
	      }
	      catch(Exception e){
	         System.out.println("Error"+e.getMessage());
	      }finally{
	         // En el finally cerramos el fichero, para asegurarnos
	         // que se cierra tanto si todo va bien como si salta 
	         // una excepcion.
	         try{                    
	            if( null != fr ){   
	               fr.close();     
	            }                  
	         }catch (Exception e2){ 
	            e2.printStackTrace();
	         }
	        
	      }
	      
	      return clientes;
	}

	public ArrayList<Cliente> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(ArrayList<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}

	@Override
	public Iterable<Cliente> findByText(String text) throws Exception {

		
		String path =  this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		String[] directorio = path.split("classes");
		String rutaCompleta = directorio[0] + rutaArchivo;
		System.out.println("ruta archivo "+rutaCompleta);
		// leer el archivo
		  File archivo = null;
	      FileReader fr = null;
	      BufferedReader br = null;
	      ArrayList<Cliente> clientes = new ArrayList<Cliente>();
	      try {
	         // Apertura del fichero y creacion de BufferedReader para poder
	         // hacer una lectura comoda (disponer del metodo readLine()).
	    	//  FileSystemResource resource = new FileSystemResource("/WEB-INF/content/somecontent.txt");
	         archivo = new File (rutaCompleta);
	         fr = new FileReader (archivo);
	         br = new BufferedReader(fr);

	         // Lectura del fichero
	         String linea;
	         while((linea=br.readLine())!=null) {
	        	 String datos[] = linea.split(",");
	        	 if (datos[0].contains(text) || datos[1].contains(text) || datos[2].contains(text) || datos[3].contains(text)  )
	        	 {
	        		 Cliente c = new Cliente(datos[0],datos[1],datos[2],datos[3]);
	        	
	        	 clientes.add(c);
	        	 }
	         }
	           
	      }
	      catch(Exception e){
	         System.out.println("Error"+e.getMessage());
	      }finally{
	         // En el finally cerramos el fichero, para asegurarnos
	         // que se cierra tanto si todo va bien como si salta 
	         // una excepcion.
	         try{                    
	            if( null != fr ){   
	               fr.close();     
	            }                  
	         }catch (Exception e2){ 
	            e2.printStackTrace();
	         }
	        
	      }
	      
	      return clientes;
	}

}
