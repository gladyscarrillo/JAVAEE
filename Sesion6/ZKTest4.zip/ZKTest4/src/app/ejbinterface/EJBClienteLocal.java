package app.ejbinterface;

import javax.ejb.Local;

import app.modelo.Cliente;



@Local
public interface EJBClienteLocal {
	public boolean insert();
	public Cliente getCliente();
	public void setCliente(Cliente cliente);
	public Iterable<Cliente> findAll() ;
	public Iterable<Cliente> findByText(String text) ;
}
