package app.ejb;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import app.dao.DaoCliente;
import app.daointerface.IDaoCliente;
import app.ejbinterface.EJBClienteLocal;
import app.modelo.Cliente;

/**
 * Session Bean implementation class EJBCliente
 */
@Stateless

public class EJBCliente implements EJBClienteLocal {


	private Cliente cliente;
    /**
     * Default constructor. 
     */
    public EJBCliente() {
        // TODO Auto-generated constructor stub
    	cliente = new Cliente();
    }

	@Override
	public boolean insert() {
		// TODO Auto-generated method stub
		System.out.println("en INSERT...");
		try {
			
		
			 IDaoCliente daoCliente = new DaoCliente();
			 daoCliente.insert(cliente);
			 return true;
	
			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return false;
	}

	@Override
	public Cliente getCliente() {
		// TODO Auto-generated method stub
		return cliente;
	}

	@Override
	public void setCliente(Cliente cliente) {
		// TODO Auto-generated method stub
		this.cliente =cliente;
	}


	@Override
	public Iterable<Cliente> findAll() {
		try {			
			 IDaoCliente daoCliente = new DaoCliente();
			 return daoCliente.findAll();

		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return null;
	}

	@Override
	public Iterable<Cliente> findByText(String text) {
		try {			
			 IDaoCliente daoCliente = new DaoCliente();
			 return daoCliente.findByText(text);

		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return null;
	}


}
