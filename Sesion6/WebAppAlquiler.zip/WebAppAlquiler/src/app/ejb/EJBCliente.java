package app.ejb;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import app.dao.DaoCliente;
import app.daointerface.IDaoCliente;
import app.ejbinterface.EJBClienteLocal;
import app.entity.Cliente;

/**
 * Session Bean implementation class EJBCliente
 */
@Stateless

public class EJBCliente implements EJBClienteLocal {
	private Cliente cliente;
    /**
     * Default constructor. 
     */
    public EJBCliente() {
    	cliente = new Cliente();
    }

	@Override
	public boolean insert() {
		try {
			 IDaoCliente daoCliente = new DaoCliente();
			 daoCliente.insert(cliente);
			 return true;
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return false;
	}

	@Override
	public Cliente getCliente() {
		// TODO Auto-generated method stub
		return cliente;
	}

	@Override
	public void setCliente(Cliente cliente) {
		// TODO Auto-generated method stub
		this.cliente =cliente;
	}

	@Override
	public Iterable<Cliente> findAll() {
		// TODO Auto-generated method stub
		return null;
	}


}
