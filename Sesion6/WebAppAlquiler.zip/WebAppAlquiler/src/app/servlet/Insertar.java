package app.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import app.ejb.EJBCliente;
import app.ejbinterface.EJBClienteLocal;

/**
 * Servlet implementation class Insertar
 */
@WebServlet("/Insertar")
public class Insertar extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EJBClienteLocal ejbCliente; //objeto ejb con la l�gica relacionada al cliente
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Insertar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.getRequestDispatcher("cliente/insertar.jsp").forward(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ejbCliente = new EJBCliente();
		//recuperar valores del formulario para crear objeto cliente
		ejbCliente.getCliente().setCedula(request.getParameter("txtCedula"));
		ejbCliente.getCliente().setNombre(request.getParameter("txtNombre"));
		ejbCliente.getCliente().setDireccion(request.getParameter("txtDireccion"));
		ejbCliente.getCliente().setEmail(request.getParameter("txtEmail"));
		//llamar al metodo insertar
		boolean retorno = ejbCliente.insert();
		request.setAttribute("res", retorno?"Datos guardados exitosamente":"Error al guardar");
		request.getRequestDispatcher("cliente/insertar.jsp").forward(request, response);
	}

}
