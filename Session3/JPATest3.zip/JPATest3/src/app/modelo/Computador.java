package app.modelo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the computador database table.
 * 
 */
@Entity
@DiscriminatorValue("COMPUTADOR") 
@NamedQueries({
@NamedQuery(name="Computador.findAll", query="SELECT c FROM Computador c"),
@NamedQuery(name="Computador.buscarMarca", 
			query="SELECT c FROM Equipo e,"
		+ "Computador c WHERE e.codigo=c.codigo "
		+ "and (e.marca=:marcaBuscar or e.marca=:marca2)"),
})

public class Computador extends Equipo implements Serializable {
	private static final long serialVersionUID = 1L;


	private String caracteristicasAd;

	private String disco;

	private String memoria;

	private String pantalla;

	private String procesador;

	private String sistemaOperativo;

	

	public Computador() {
	}

	public Computador(String codigo, String descripcion, String marca, float precio,String pantalla, String disco,
			String memoria,  String procesador,
			String sistemaOperativo,String caracteristicasAd) {
		super(codigo,descripcion,marca,precio);
		this.caracteristicasAd = caracteristicasAd;
		this.disco = disco;
		this.memoria = memoria;
		this.pantalla = pantalla;
		this.procesador = procesador;
		this.sistemaOperativo = sistemaOperativo;
	}



	public String getCaracteristicasAd() {
		return this.caracteristicasAd;
	}

	public void setCaracteristicasAd(String caracteristicasAd) {
		this.caracteristicasAd = caracteristicasAd;
	}

	public String getDisco() {
		return this.disco;
	}

	public void setDisco(String disco) {
		this.disco = disco;
	}

	public String getMemoria() {
		return this.memoria;
	}

	public void setMemoria(String memoria) {
		this.memoria = memoria;
	}

	public String getPantalla() {
		return this.pantalla;
	}

	public void setPantalla(String pantalla) {
		this.pantalla = pantalla;
	}

	public String getProcesador() {
		return this.procesador;
	}

	public void setProcesador(String procesador) {
		this.procesador = procesador;
	}

	public String getSistemaOperativo() {
		return this.sistemaOperativo;
	}

	public void setSistemaOperativo(String sistemaOperativo) {
		this.sistemaOperativo = sistemaOperativo;
	}


	@Override
	public String toString() {
		return "Computador" + super.toString() +", caracteristicasAd=" + caracteristicasAd + "]";
	}

}