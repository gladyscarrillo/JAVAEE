package app.modelo;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the cliente database table.
 * 
 */
@Entity
@NamedQuery(name="Cliente.findAll", query="SELECT c FROM Cliente c")
public class Cliente implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String cedula;

	private String direccion;

	private String email;

	private String nombre;

	//bi-directional many-to-one association to Ordenalquiler
	@OneToMany(mappedBy="cliente")
	private List<Ordenalquiler> ordenalquilers;

	public Cliente() {
	}

	public Cliente(String cedula, String direccion, String email, String nombre) {
		this.cedula = cedula;
		this.direccion = direccion;
		this.email = email;
		this.nombre = nombre;
	}

	public String getCedula() {
		return this.cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Ordenalquiler> getOrdenalquilers() {
		return this.ordenalquilers;
	}

	public void setOrdenalquilers(List<Ordenalquiler> ordenalquilers) {
		this.ordenalquilers = ordenalquilers;
	}

	public Ordenalquiler addOrdenalquiler(Ordenalquiler ordenalquiler) {
		getOrdenalquilers().add(ordenalquiler);
		ordenalquiler.setCliente(this);

		return ordenalquiler;
	}

	public Ordenalquiler removeOrdenalquiler(Ordenalquiler ordenalquiler) {
		getOrdenalquilers().remove(ordenalquiler);
		ordenalquiler.setCliente(null);

		return ordenalquiler;
	}

	@Override
	public String toString() {
		return "Cliente [cedula=" + cedula + ", nombre=" + nombre + "]";
	}
	

}