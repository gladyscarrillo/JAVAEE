package app.modelo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the equipo database table.
 * 
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "TIPO_EQUIPO", discriminatorType = DiscriminatorType.STRING)
@NamedQuery(name="Equipo.findAll", query="SELECT e FROM Equipo e")
public class Equipo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String codigo;

	private float costoAlquiler;

	private String description;

	private String marca;

	@Column(name="tipo_equipo")
	private String tipoEquipo;

	

	public Equipo() {
	}
	public Equipo(String codigo, String description, String marca, float costoAlquiler) {
		this.codigo = codigo;
		this.description = description;
		this.marca = marca;
		this.costoAlquiler = costoAlquiler;
	}

	public String getCodigo() {
		return this.codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public float getCostoAlquiler() {
		return this.costoAlquiler;
	}

	public void setCostoAlquiler(float costoAlquiler) {
		this.costoAlquiler = costoAlquiler;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMarca() {
		return this.marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getTipoEquipo() {
		return this.tipoEquipo;
	}

	public void setTipoEquipo(String tipoEquipo) {
		this.tipoEquipo = tipoEquipo;
	}

	@Override
	public String toString() {
		return " [codigo=" + codigo + ", costoAlquiler=" + costoAlquiler + ", description=" + description ;
	}

}