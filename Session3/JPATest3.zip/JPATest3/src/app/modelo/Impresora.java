package app.modelo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the impresora database table.
 * 
 */
@Entity
@DiscriminatorValue("IMPRESORA") 
@NamedQuery(name="Impresora.findAll", query="SELECT i FROM Impresora i")
public class Impresora extends Equipo implements Serializable {
	private static final long serialVersionUID = 1L;


	private boolean conexionWifi;
	@Enumerated(EnumType.STRING)
	private TipoImpresion tipoImpresion;



	public Impresora() {
	}
	public Impresora(String codigo, String descripcion, String marca, float precio, TipoImpresion tipoImpresion,boolean conexionWifi) {
		super(codigo,descripcion,marca,precio);
		this.conexionWifi = conexionWifi;
		this.tipoImpresion = tipoImpresion;
	}


	public boolean getConexionWifi() {
		return this.conexionWifi;
	}

	public void setConexionWifi(boolean conexionWifi) {
		this.conexionWifi = conexionWifi;
	}

	public TipoImpresion getTipoImpresion() {
		return this.tipoImpresion;
	}

	public void setTipoImpresion(TipoImpresion tipoImpresion) {
		this.tipoImpresion = tipoImpresion;
	}
	@Override
	public String toString() {
		return "Impresora "+ super.toString()+ ",conexionWifi=" + conexionWifi + ", tipoImpresion=" + tipoImpresion + "]";
	}



}