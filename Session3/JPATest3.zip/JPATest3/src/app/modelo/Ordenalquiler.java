package app.modelo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ordenalquiler database table.
 * 
 */
@Entity
@NamedQuery(name="Ordenalquiler.findAll", query="SELECT o FROM Ordenalquiler o")
public class Ordenalquiler implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	private short diasAlquiler;

	private String fecha;

	//bi-directional many-to-one association to Cliente
	@ManyToOne
	@JoinColumn(name="id_cliente")
	private Cliente cliente;

	public Ordenalquiler() {
		
	}
	

	public Ordenalquiler(short diasAlquiler, String fecha, Cliente cliente) {
		this.diasAlquiler = diasAlquiler;
		this.fecha = fecha;
		this.cliente = cliente;
	}


	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public short getDiasAlquiler() {
		return this.diasAlquiler;
	}

	public void setDiasAlquiler(short diasAlquiler) {
		this.diasAlquiler = diasAlquiler;
	}

	public String getFecha() {
		return this.fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Cliente getCliente() {
		return this.cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}


	@Override
	public String toString() {
		return "Ordenalquiler [id=" + id + ", diasAlquiler=" + diasAlquiler + ", fecha=" + fecha + ", cliente="
				+ cliente + "]";
	}

}