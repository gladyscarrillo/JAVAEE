package app.modelo;

public enum TipoImpresion {
	TONER,LASER
}
