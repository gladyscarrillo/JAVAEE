package app.test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import app.modelo.Cliente;
import app.modelo.Computador;
import app.modelo.Ordenalquiler;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//insertarComputador();
		//consultar();
		//consultarPorMarca();
		consultarPorPrecio();
	//	insertarOrden() ;
		//consultarOrdenesCliente();
	}


	public static void insertarComputador() {
		System.out.println("Insertar..");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPATest3");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		try {
			//cambiar los datos para no tener duplicados
			
			Computador com1 =new Computador("1020","Computador portatil 17''","LENOVO",80.0f,"17 \"","1TB","8GB","Intel i3","Windows 10","Camara web integrada, 3 puertos usb");
			//Computador com1 =new Computador("1002","Computador portatil 14''","HP",60.0f,"14 \"","1TB","4GB","Intel i3","Windows 10","Camara web integrada, 3 puertos usb");
			//Computador com1 =new Computador("1003","Computador de escritorio 15''","HP",70.0f,"14 \"","1TB","8GB","Intel i3","Windows 10","tarjeta grafica");
		 
	
			et.begin();
			em.persist(com1);
			et.commit();
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());

		} finally {
			em.close();
		}

	}

	public static void consultar() {
		System.out.println("Consultar..");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPATest3");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		try {
			
			et.begin();
			TypedQuery<Computador> query = em.createNamedQuery("Computador.findAll",Computador.class);
			List<Computador> lista = query.getResultList();
			et.commit();
			
			for(Computador c:lista) {
				System.out.println(c);
			}
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());

		} finally {
			em.close();
		}

	}

	

	public static void consultarPorMarca() {
		System.out.println("Consultar por marca..");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPATest3");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		try {
			
			et.begin();
			TypedQuery<Computador> query = em.createNamedQuery("Computador.buscarMarca",Computador.class);
			query.setParameter("marcaBuscar", "HP");
			query.setParameter("marca2", "LENOVO");
			List<Computador> lista = query.getResultList();
			et.commit();
			
			for(Computador c:lista) {
				System.out.println(c);
			}
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());

		} finally {
			em.close();
		}

	}
	
	

	public static void consultarPorPrecio() {
		System.out.println("Consultar por precio..");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPATest3");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		try {
	        String sQuery ="SELECT c FROM Computador c, Equipo e "
	        		+ "WHERE e.codigo = c.codigo and e.costoAlquiler<80 ";
			et.begin();
			List<Computador> lista = em.createQuery(sQuery).getResultList();
			
			et.commit();
			
			for(Computador c:lista) {
				System.out.println(c);
			}
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());

		} finally {
			em.close();
		}

	}
	
	

	public static void insertarOrden() {
		System.out.println("Insertar orden..");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPATest3");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		try {
			
			//buscar clliente
			Cliente cliente = em.find(Cliente.class, "77777755");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			String fecha =sdf.format(new Date());
			short dias=4;
			Ordenalquiler orden = new Ordenalquiler(dias,fecha,cliente);
			
			et.begin();
			em.persist(orden);
			et.commit();
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());

		} finally {
			em.close();
		}

	}



	public static void consultarOrdenesCliente() {
		System.out.println("consultar orden de cliente..");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPATest3");
		EntityManager em = emf.createEntityManager();
	

		try {
			
			//buscar clliente
			Cliente cliente = em.find(Cliente.class, "77777755");
			//recuperar sus ordenes y mostrar
			for (Ordenalquiler orden:cliente.getOrdenalquilers()) {
				System.out.println(orden);
			}
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());

		} finally {
			em.close();
		}

	}



}
